# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.14",
        python_install_dir=r"/usr/local/lib/python3.14/site-packages/",
        python_path=r"/home/runner/work/mobile-forge/mobile-forge/build/cp314/contourpy/1.3.3/venv3.14-android_24_arm64_v8a/cross/bin/python3.14",

        # Package versions
        contourpy_version="1.3.3",
        meson_version="1.11.1",
        mesonpy_version="0.20.0",
        pybind11_version="3.0.4",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/home/runner/work/mobile-forge/mobile-forge/build/cp314/contourpy/1.3.3/.mesonpy-szk1golt/lib/contourpy/util",
        source_dir=r"/home/runner/work/mobile-forge/mobile-forge/build/cp314/contourpy/1.3.3/lib/contourpy/util",
        cross_build="True",

        # Build options
        build_options=r"-Dbuildtype=release -Db_ndebug=if-release -Db_vscrt=md -Dvsenv=true --cross-file=/home/runner/work/mobile-forge/mobile-forge/build/cp314/contourpy/1.3.3/meson.cross --native-file=/home/runner/work/mobile-forge/mobile-forge/build/cp314/contourpy/1.3.3/.mesonpy-szk1golt/meson-python-native-file.ini",
        buildtype="release",
        cpp_std="c++17",
        debug="False",
        optimization="3",
        vsenv="True",
        b_ndebug="if-release",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="clang",
        compiler_version="18.0.4",
        linker_id="ld.lld",
        compile_command="/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android24-clang++",

        # Host machine
        host_cpu="aarch64",
        host_cpu_family="aarch64",
        host_cpu_endian="little",
        host_cpu_system="android",

        # Build machine, same as host machine if not a cross_build
        build_cpu="x86_64",
        build_cpu_family="x86_64",
        build_cpu_endian="little",
        build_cpu_system="linux",
    )
