Type getTypeOf<T>() => T;
